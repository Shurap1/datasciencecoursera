#!/bin/bash



export CONFIG_FILE=
export LOCAL_CP=
export INSTALL_DIR=



if [[ $0 =~ "^/.*$" ]]; then
	export INSTALL_DIR=$0
	export INSTALL_DIR=`echo "$INSTALL_DIR" | sed 's/\/sqldirbrowser\.sh//'`	
else
	export INSTALL_DIR="$0"
        export INSTALL_DIR=`echo "$INSTALL_DIR" | sed 's/\/sqldirbrowser\.sh//'`
	export INSTALL_DIR=`echo "$INSTALL_DIR" | sed 's/\.//'`
	export INSTALL_DIR=`pwd`$INSTALL_DIR
fi


for jarFile in `ls $INSTALL_DIR`
do
	export LOCAL_CP="$INSTALL_DIR/$jarFile:$LOCAL_CP"
done

export CLASSPATH=$LOCAL_CP


java -Djava.library.path=$INSTALL_DIR com.octetstring.jdbcLdap.browser.JdbcLdapBrowserApp
